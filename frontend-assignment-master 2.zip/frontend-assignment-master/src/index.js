import React from 'react';
import ReactDOM from 'react-dom';

const App = () => <h1>Hello, React!

{/* KickstarterProjects */}
</h1>;

ReactDOM.render(<App />, document.getElementById('root'));

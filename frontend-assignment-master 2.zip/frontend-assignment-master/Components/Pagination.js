import React from "react";

const Pagination = ({ currentPage, totalPages, onPageChange }) => {
    const pages = [];
    for (let i = 1; i <= totalPages; i++) {
        pages.push(
            <button
                key={i}
                onClick={() => onPageChange(i)}
                className={`px-3 py-1 m-1 rounded ${
                    currentPage === i ? "bg-blue-500 text-white" : "bg-gray-200"
                }`}
            >
                {i}
            </button>
        );
    }
    return <div className="mt-4">{pages}</div>;
};

export default Pagination;
